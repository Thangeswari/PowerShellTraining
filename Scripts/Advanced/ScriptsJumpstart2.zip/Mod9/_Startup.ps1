﻿ise -file ".\MyTools.ps1, .\Launch.ps1, .\Manifest.ps1, .\WithView.ps1, .\MAnifestview.ps1"
