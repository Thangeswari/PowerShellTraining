﻿New-ModuleManifest -Path 'C:\Users\student.COMPANY\Documents\WindowsPowerShell\Modules\MyTools\MyTools.psd1' `
-Author Jason -CompanyName MyCompany -Copyright '(c)2013 JumpStart' `
-ModuleVersion 1.0 -Description 'The JumpStart module' `
-PowerShellVersion 3.0 -RootModule .\MyTools.psm1 -FormatsToProcess .\JasonTypes.Format.Ps1xml

