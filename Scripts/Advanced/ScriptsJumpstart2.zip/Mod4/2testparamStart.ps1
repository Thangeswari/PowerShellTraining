﻿
Function Get-CompInfo{
    [CmdletBinding()]
    Param(
        #Want to support multiple computers
        [String]$ComputerName,
        #Switch to turn on Error logging
        [Switch]$ErrorLog,
        [String]$LogFile = 'c:\errorlog.txt'
    )
    Begin{}
    Process{}
    End{}

}

